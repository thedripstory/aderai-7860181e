import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ErrorLogger } from '@/lib/errorLogger';

// Bundle definitions - each bundle expands to multiple segment IDs
const SEGMENT_BUNDLES: Record<string, string[]> = {
  'core-essentials': [
    'engaged-30-days',
    'repeat-customers', 
    'cart-abandoners',
    'vip-customers',
    'recent-purchasers-30'
  ],
  'engagement-maximizer': [
    'highly-engaged',
    'email-openers-30',
    'email-clickers-30',
    'recent-clickers-90',
    'active-site-30'
  ],
  'lifecycle-manager': [
    'new-subscribers',
    'first-time-buyers',
    'repeat-customers',
    'at-risk-customers',
    'churned-customers',
    'vip-customers'
  ],
  'shopping-behavior': [
    'cart-abandoners',
    'browse-abandoners',
    'product-viewers',
    'checkout-starters',
    'frequent-browsers'
  ],
  'smart-exclusions': [
    'recent-purchasers-exclusion',
    'unengaged-exclusion',
    'never-engaged-exclusion',
    'bounced-emails'
  ]
};

export interface SegmentResult {
  segmentId: string;
  status: "success" | "error" | "skipped";
  message: string;
  klaviyoId?: string;
}

export interface KlaviyoKey {
  id: string;
  client_name: string;
  klaviyo_api_key_hash: string;
  currency: string;
  currency_symbol: string;
  aov: number;
  vip_threshold: number;
  high_value_threshold: number;
  new_customer_days: number;
  lapsed_days: number;
  churned_days: number;
  is_active: boolean;
}

export const useKlaviyoSegments = () => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SegmentResult[]>([]);
  const [progress, setProgress] = useState({ current: 0, total: 0 });

  const createSegments = async (
    selectedSegments: string[],
    activeKey: KlaviyoKey,
    segmentsList: any[],
    jobId?: string
  ) => {
    console.log('[useKlaviyoSegments] createSegments called with:', {
      selectedSegmentsCount: selectedSegments.length,
      selectedSegments: selectedSegments,
      activeKeyId: activeKey.id,
    });

    if (selectedSegments.length === 0) {
      throw new Error('Please select at least one segment to create');
    }

    // Expand any bundle IDs into their component segments
    let expandedSegmentIds = [...selectedSegments];
    selectedSegments.forEach(id => {
      if (SEGMENT_BUNDLES[id]) {
        // Remove the bundle ID and add its component segments
        expandedSegmentIds = expandedSegmentIds.filter(s => s !== id);
        expandedSegmentIds.push(...SEGMENT_BUNDLES[id]);
      }
    });
    // Remove duplicates
    expandedSegmentIds = [...new Set(expandedSegmentIds)];
    
    console.log('[useKlaviyoSegments] Expanded segment IDs:', expandedSegmentIds);

    setLoading(true);
    setResults([]);
    setProgress({ current: 0, total: expandedSegmentIds.length });

    try {
      const currencySymbol = activeKey.currency_symbol || '$';
      
      const settings = {
        highValue: activeKey.vip_threshold || 1000,
        mediumValue: activeKey.high_value_threshold || 500,
        lowValue: activeKey.aov || 100,
        atRiskDays: activeKey.lapsed_days || 180,
        lostDays: activeKey.churned_days || 365,
        recentDays: activeKey.new_customer_days || 30,
        activeDays: 90,
        vipThreshold: activeKey.vip_threshold || 1000,
        highValueThreshold: activeKey.high_value_threshold || 500,
        aov: activeKey.aov || 100,
      };

      // Use expanded segment IDs for API call
      console.log('[useKlaviyoSegments] Sending to edge function:', {
        segmentIdsCount: expandedSegmentIds.length,
        segmentIds: expandedSegmentIds,
      });

      // Save progress if jobId provided
      if (jobId) {
        await supabase
          .from('segment_creation_jobs')
          .update({
            status: 'in_progress',
            segments_processed: 0,
            total_segments: expandedSegmentIds.length
          })
          .eq('id', jobId);
      }

      console.log('Creating segments:', expandedSegmentIds);

      const requestBody = {
        apiKey: activeKey.klaviyo_api_key_hash,
        segmentIds: expandedSegmentIds,
        currencySymbol,
        settings,
      };
      
      console.log('[useKlaviyoSegments] Request body:', JSON.stringify(requestBody, null, 2));

      const { data: response, error } = await supabase.functions.invoke('klaviyo-create-segments', {
        body: requestBody,
      });

      console.log('[useKlaviyoSegments] Edge function response:', { response, error });

      if (error) {
        console.error('[useKlaviyoSegments] Supabase function error:', error);
        throw error;
      }

      if (!response) {
        console.error('[useKlaviyoSegments] No response from edge function');
        throw new Error('No response from segment creation service');
      }

      // Handle case where response doesn't have results array
      const resultsArray = response.results || [];
      console.log('[useKlaviyoSegments] Results array:', resultsArray);

      // Log metrics availability for debugging
      if (response.missingMetrics && response.missingMetrics.length > 0) {
        console.warn('[useKlaviyoSegments] Missing Klaviyo metrics:', response.missingMetrics);
        console.warn('[useKlaviyoSegments]', response.metricsNote);
      }

      // Notify user about missing metrics
      if (response.missingMetrics && response.missingMetrics.length > 0 && response.summary?.skipped > 0) {
        console.info(`Note: ${response.summary.skipped} segments were skipped. ${response.metricsNote}`);
      }

      // Create a map of results by segmentId for reliable lookup
      const resultsMap = new Map<string, any>();
      resultsArray.forEach((result: any) => {
        if (result && result.segmentId) {
          resultsMap.set(result.segmentId, result);
        }
      });

      console.log('[useKlaviyoSegments] Results map keys:', Array.from(resultsMap.keys()));

      const newResults: SegmentResult[] = expandedSegmentIds.map((segmentId) => {
        const segment = segmentsList.find((s: any) => s.id === segmentId);
        const segmentName = segment?.name || segmentId;
        const result = resultsMap.get(segmentId);

        console.log(`[useKlaviyoSegments] Processing segment ${segmentId}:`, { result, segmentName });

        if (!result) {
          return {
            segmentId,
            status: "error" as const,
            message: `Failed to create "${segmentName}": No response from server`,
          };
        }

        const resultStatus = result.status;

        if (resultStatus === 'created') {
          // Log the operation for audit trail
          logSegmentOperation(segmentId, segmentName, 'create', 'success', activeKey.id, result.klaviyoId);
          return {
            segmentId,
            status: "success" as const,
            message: `Successfully created "${segmentName}"`,
            klaviyoId: result.data?.data?.id || result.klaviyoId,
          };
        } else if (resultStatus === 'exists') {
          return {
            segmentId,
            status: "skipped" as const,
            message: `"${segmentName}" already exists`,
          };
        } else if (resultStatus === 'skipped' || resultStatus === 'missing_metrics') {
          return {
            segmentId,
            status: "skipped" as const,
            message: `"${segmentName}" skipped: Required metrics not available in your Klaviyo account`,
          };
        } else {
          // Log failed operations
          logSegmentOperation(segmentId, segmentName, 'create', 'failed', activeKey.id, undefined, result.error);
          return {
            segmentId,
            status: "error" as const,
            message: `Failed to create "${segmentName}": ${result.error || 'Unknown error'}`,
          };
        }
      });

      setResults(newResults);

      // Update job completion
      if (jobId) {
        const successCount = newResults.filter(r => r.status === 'success').length;
        await supabase
          .from('segment_creation_jobs')
          .update({
            status: 'completed',
            segments_processed: expandedSegmentIds.length,
            completed_at: new Date().toISOString(),
            success_count: successCount,
            error_count: newResults.filter(r => r.status === 'error').length
          })
          .eq('id', jobId);
      }

      return newResults;
    } catch (error: any) {
      console.error('Segment creation error:', error);
      
      // Log error to database for production monitoring
      await ErrorLogger.logSegmentError(
        `Batch creation (${expandedSegmentIds.length} segments)`,
        error,
        { 
          expandedSegmentIds, 
          activeKeyId: activeKey.id,
          jobId 
        }
      );
      
      if (jobId) {
        await supabase
          .from('segment_creation_jobs')
          .update({
            status: 'failed',
            error_message: error.message
          })
          .eq('id', jobId);
      }

      const errorResults: SegmentResult[] = expandedSegmentIds.map((segmentId) => {
        const segment = segmentsList.find((s: any) => s.id === segmentId);
        return {
          segmentId,
          status: "error" as const,
          message: `Failed to create "${segment?.name || segmentId}": ${error.message || 'Unknown error'}`,
        };
      });
      
      setResults(errorResults);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    results,
    progress,
    createSegments,
    setResults,
  };
};

// Helper function to log segment operations for audit trail
async function logSegmentOperation(
  segmentId: string,
  segmentName: string | undefined,
  operationType: string,
  status: string,
  klaviyoKeyId: string,
  klaviyoSegmentId?: string,
  errorMessage?: string
) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('segment_operations').insert({
      user_id: user.id,
      klaviyo_key_id: klaviyoKeyId,
      segment_name: segmentName || segmentId,
      segment_klaviyo_id: klaviyoSegmentId,
      operation_type: operationType,
      operation_status: status,
      error_message: errorMessage,
      metadata: { segmentId },
    });
  } catch (err) {
    console.error('Failed to log segment operation:', err);
  }
}
